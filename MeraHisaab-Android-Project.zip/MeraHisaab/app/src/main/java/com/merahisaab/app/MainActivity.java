package com.merahisaab.app;

import android.os.Bundle;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.signin.*;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.auth.*;

public class MainActivity extends AppCompatActivity {
  private static final int RC_SIGN_IN=1001; private FirebaseAuth auth; private TextView status;
  @Override public void onCreate(@Nullable Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); auth=FirebaseAuth.getInstance(); status=findViewById(R.id.status);
    Button login=findViewById(R.id.login); login.setOnClickListener(v->signIn());
    FirebaseUser u=auth.getCurrentUser(); if(u!=null) status.setText("Google backup: "+u.getDisplayName());
    findViewById(R.id.addExpense).setOnClickListener(v->toast("Add Expense screen ready for next module"));
    findViewById(R.id.parties).setOnClickListener(v->toast("Parties screen ready for next module"));
    findViewById(R.id.reports).setOnClickListener(v->toast("Reports screen ready for next module")); }
  private void signIn(){String id=getString(R.string.default_web_client_id); if(id.startsWith("YOUR_")){toast("Firebase Console mein Google Sign-In enable karke Web Client ID add karni hogi");return;} GoogleSignInOptions o=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(id).requestEmail().build(); startActivityForResult(GoogleSignIn.getClient(this,o).getSignInIntent(),RC_SIGN_IN);}
  @Override protected void onActivityResult(int r,int c,android.content.Intent d){super.onActivityResult(r,c,d);if(r==RC_SIGN_IN){try{GoogleSignInAccount a=GoogleSignIn.getSignedInAccountFromIntent(d).getResult(ApiException.class);auth.signInWithCredential(GoogleAuthProvider.getCredential(a.getIdToken(),null)).addOnCompleteListener(this,t->{if(t.isSuccessful()&&auth.getCurrentUser()!=null)status.setText("Google backup: "+auth.getCurrentUser().getDisplayName());else toast("Login failed");});}catch(Exception e){toast("Google login cancel/failed");}}}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
