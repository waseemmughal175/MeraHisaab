# Mera Hisaab — Android Project

Dark-theme starter project for the Mera Hisaab accounting app. It includes the supplied Firebase `google-services.json`, Firebase Auth dependency, and a Google Sign-In button.

## Important Firebase step
The supplied `google-services.json` has an empty OAuth client list. In Firebase Console:
1. Open project **mera-hisaab-918b8**.
2. Authentication → Sign-in method → enable **Google**.
3. Project settings → Your apps → Android app `com.merahisaab.app` → add SHA-1/SHA-256 fingerprints for the signing key used to build the app.
4. Download the refreshed `google-services.json` if Firebase provides one and replace `app/google-services.json`.
5. Add the Web application OAuth client ID to `app/src/main/res/values/strings.xml` as `default_web_client_id`.

## Build
Open this folder in Android Studio and let Gradle sync. Then Build → Build APK(s).

The environment used to prepare this package does not include a complete Android SDK/Gradle installation, so an APK could not be compiled here. The source project itself is ready to open in Android Studio.
